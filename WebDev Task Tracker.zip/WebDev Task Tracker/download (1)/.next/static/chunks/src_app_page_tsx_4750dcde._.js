(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_4750dcde._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_4750dcde._.js",
  "chunks": [
    "static/chunks/node_modules_46018bee._.js",
    "static/chunks/src_c62a1123._.js"
  ],
  "source": "dynamic"
});
