# **App Name**: WebDev Task Tracker

## Core Features:

- Task Input: Simple form to input new tasks with a description and status.
- Task List: Display tasks in a list with status indicators.
- Status Updates: Allow users to mark tasks as 'In Progress', 'Completed', or 'Blocked'.

## Style Guidelines:

- Primary color: Dark blue (#2c3e50) for a professional feel.
- Secondary color: Light gray (#ecf0f1) for backgrounds and subtle elements.
- Accent: Teal (#3498db) for interactive elements and status indicators.
- Clean and well-spaced layout for readability.
- Use simple, clear icons to represent task statuses.
- Subtle transitions when updating task statuses.

## Original User Request:
Develop and maintain both front-end and back-end components of web applications
Write clean, efficient, and well-documented code
Collaborate with the team to design, develop, and test new features
Participate in code reviews and provide constructive feedback
Troubleshoot and debug application issues
Assist in the deployment and maintenance of applications
Stay up-to-date with the latest web development technologies and trends
  